<!--	This is getting executing on click of submit and validate button -->
function fnValidateData() {
		if (!fnCheckMandatoryFields())
		{
			return false;
		}
		return true;
}

function appear(){	
		
		var funcCode = document.getElementById("funcCode").value;
		//alert(funcCode);
		var tranDate = document.getElementById("tranDate").value;
		var Amt = document.getElementById("Amt").value;
		var isdn = document.getElementById("isdn").value;
		if ((funcCode != "")||(funcCode != '')){
				if (tranDate == ""){
					alert ("Enter Transaction Date");
					document.getElementById("tranDate").focus();
					return false;
				}
				if (Amt == ""){
					alert ("Enter Transaction Amount");
					document.getElementById("Amt").focus();
					return false;
				}
				
				if (isdn == ""){
					alert ("Enter ISDN number");
					document.getElementById("isdn").focus();
					return false;
				}
			var inputNameValues="funcCode|"+funcCode+"|tranDate|"+tranDate+"|Amt|"+Amt+"|isdn|"+isdn; 
			var outputNames= "uniqueReference|bankBranchid|bankId|batchId|branchPhoneno|bvn|cbnAcct|channel|collectedAmount|currency|customerAccount|customerEmail|customerName|customerPhone|customerTin|fee|feedType|gifmisCode|itemCode|itemName|locationCode|mdaCode|mdaName|narrationDesc|payColDate|psspCode|psspName|remittedAmount|requestedAmount|sessionId|settlementRef|tsaPcCodename|tsaPcCoderef|valueDate|whoPays|res|notifyFlag";
			var scrName="tsadia.scr";
			var retVal = appFnExecuteScript(inputNameValues, outputNames, scrName, true);
			objForm=document.forms[0];
			objForm.uniqueReference.disabled = true;
			objForm.bankBranchid.disabled = true;
			objForm.bankId.disabled = true;
			objForm.batchId.disabled = true;
			objForm.branchPhoneno.disabled = true;
			objForm.bvn.disabled = true;
			objForm.cbnAcct.disabled = true;
			objForm.channel.disabled = true;
			objForm.collectedAmount.disabled = true;
			objForm.currency.disabled = true;
			objForm.customerAccount.disabled = true;
			objForm.customerEmail.disabled = true;
			objForm.customerName.disabled = true;
			objForm.customerPhone.disabled = true;
			objForm.customerTin.disabled = true;
			objForm.fee.disabled = true;
			objForm.feedType.disabled = true;
			objForm.gifmisCode.disabled = true;
			objForm.itemCode.disabled = true;
			objForm.itemName.disabled = true;
			objForm.locationCode.disabled = true;
			objForm.mdaCode.disabled = true;
			objForm.mdaName.disabled = true;
			objForm.narrationDesc.disabled = true;
			objForm.payColDate.disabled = true;
			objForm.psspCode.disabled = true;
			objForm.psspName.disabled = true;
			objForm.remittedAmount.disabled = true;
			objForm.requestedAmount.disabled = true;
			objForm.sessionId.disabled = true;
			objForm.settlementRef.disabled = true;
			objForm.tsaPcCodename.disabled = true;
			objForm.tsaPcCoderef.disabled = true;
			objForm.valueDate.disabled = true;
			objForm.whoPays.disabled = true;
			objForm.res.disabled = true;
			objForm.notifyFlag.disabled = true;
		}	
}


<!-- This function is added for formatting a particular MRH Row -->

function formatRowValue(Obj, colNumber) {

      return Obj;

       }


<!-- This function is added for formatting a particular MRH Row -->

function fnValidateForm(obj){
	objForm = document.forms[0];

	return true;

}
function printBlock()
{
	writeCustomHeader("tsarc_det");
	with (document){
	write('<table border="0" cellspacing="0" cellpadding="0" class="ctable">');
	write('<tr>');
	write('<td>');
	write('<table border="0" cellspacing="0" cellpadding="0">');
	write('<tr>');
	write('<td class="page-heading">' + jspResArr.get("FLT090358") + '</td>');
	write('</tr>');
	write('</table>');
	write('<table border="0" cellpadding="0" cellspacing="0" width="100%">');
	write('<tr>');
	write('<td class="textlabel"> </td>');
	write('<td class="textfielddisplaylabel"> </td>');
	write('<td class="columnwidth">&nbsp; </td>');
	write('<td class="textlabel"> </td>');
	write('<td class="textfielddisplaylabel"> </td>');
	write('</tr>');
	write('</table>');
	write('<br />');
	write('<!-- DETAILSBLOCK-BEGIN -->');
	write('<table border="0" cellpadding="0" cellspacing="0" width="100%">');
	write('<tr>');
	write('<td valign="top">');
	write('<table width="100%" border="0" cellpadding="0" cellspacing="0" class="table">');
	write('<tr>');
	write('<td>');
	write('<table width="100%" border="0" cellpadding="0" cellspacing="0" class="innertable">');
	write('<tr>');
	write('<td>');
	write('<table width="100%" border="0" cellpadding="0" cellspacing="0" class="innertabletop1">');
	write('<tr>');
	write('<td height="25" colspan="5" align="right">');
	write('<table border="0" cellspacing="0" cellpadding="0">');
	write('<tr>');
	write('<td align="right">');
	write('<a href="javascript:showHelpFile(\'det_help.htm\');" id="sLnk1">');
	write('<img  hotKeyId="finHelp" src="../Renderer/images/'+applangcode+'/help.gif" width="17" height="17" vspace="1" border="0" />');
	write('</a>');
	write('</td>');
	write('</tr>');
	write('</table>');
	write('</td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT006657") + '</td>');
	write('<td class="textfield">');
	write('<select onchange="appear()" name="' + subGroupName + '.funcCode" id="funcCode" ' + tsarcProps.get("funcCode_ENABLED") + '  >');
	write('<option value="A">' + jspResArr.get("FLT011910") + '</option>');
	write('<option value="M">' + jspResArr.get("FLT012308") + '</option>');
	write('<option value="I">' + jspResArr.get("FLT012129") + '</option>');
	write('<option value="V">' + jspResArr.get("FLT028094") + '</option>');
	write('</select>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT021862") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" onchange="appear()" class="textfieldfont" name="' + subGroupName + '.tranDate" id="tranDate" ' + tsarcProps.get("tranDate_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090391") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" onchange="appear()" class="textfieldfont" name="' + subGroupName + '.isdn" id="isdn" ' + tsarcProps.get("isdn_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090392") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" onchange="appear()" class="textfieldfont" name="' + subGroupName + '.Amt" id="Amt" ' + tsarcProps.get("Amt_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090359") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.settlementref" id="settlementref" ' + tsarcProps.get("settlementref_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090360") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.uniqueReference" id="uniqueReference" ' + tsarcProps.get("uniqueReference_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090361") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.bankBranchid" id="bankBranchid" ' + tsarcProps.get("bankBranchid_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090362") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.bankId" id="bankId" ' + tsarcProps.get("bankId_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090363") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.batchId" id="batchId" ' + tsarcProps.get("batchId_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090364") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.branchPhoneno" id="branchPhoneno" ' + tsarcProps.get("branchPhoneno_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090365") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.bvn" id="bvn" ' + tsarcProps.get("bvn_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090366") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.cbnAcct" id="cbnAcct" ' + tsarcProps.get("cbnAcct_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT008988") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.channel" id="channel" ' + tsarcProps.get("channel_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090367") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.collectedAmount" id="collectedAmount" ' + tsarcProps.get("collectedAmount_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT030604") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.currency" id="currency" ' + tsarcProps.get("currency_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090368") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.customerAccount" id="customerAccount" ' + tsarcProps.get("customerAccount_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090369") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.customerEmail" id="customerEmail" ' + tsarcProps.get("customerEmail_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT016488") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.customerName" id="customerName" ' + tsarcProps.get("customerName_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090370") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.customerPhone" id="customerPhone" ' + tsarcProps.get("customerPhone_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090371") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.customerTin" id="customerTin" ' + tsarcProps.get("customerTin_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT001628") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.fee" id="fee" ' + tsarcProps.get("fee_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT020259") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.feedType" id="feedType" ' + tsarcProps.get("feedType_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090372") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.gifmisCode" id="gifmisCode" ' + tsarcProps.get("gifmisCode_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090373") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.itemCode" id="itemCode" ' + tsarcProps.get("itemCode_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090374") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.itemName" id="itemName" ' + tsarcProps.get("itemName_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT000016") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.locationCode" id="locationCode" ' + tsarcProps.get("locationCode_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090375") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.mdaCode" id="mdaCode" ' + tsarcProps.get("mdaCode_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090376") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.mdaName" id="mdaName" ' + tsarcProps.get("mdaName_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090377") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.narrationDesc" id="narrationDesc" ' + tsarcProps.get("narrationDesc_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090378") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.payColDate" id="payColDate" ' + tsarcProps.get("payColDate_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090379") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.psspCode" id="psspCode" ' + tsarcProps.get("psspCode_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090380") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.psspName" id="psspName" ' + tsarcProps.get("psspName_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090381") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.remittedAmount" id="remittedAmount" ' + tsarcProps.get("remittedAmount_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090382") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.requestedAmount" id="requestedAmount" ' + tsarcProps.get("requestedAmount_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090383") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.sessionId" id="sessionId" ' + tsarcProps.get("sessionId_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090384") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.settlementRef" id="settlementRef" ' + tsarcProps.get("settlementRef_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090385") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.tsaPcCodename" id="tsaPcCodename" ' + tsarcProps.get("tsaPcCodename_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090386") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.tsaPcCoderef" id="tsaPcCoderef" ' + tsarcProps.get("tsaPcCoderef_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT000591") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.valueDate" id="valueDate" ' + tsarcProps.get("valueDate_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090387") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.whoPays" id="whoPays" ' + tsarcProps.get("whoPays_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('<tr>');
	write('<td class="textlabel" style="height: 15px">' + jspResArr.get("FLT090388") + '</td>');
	write('<td class="textfield">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.res" id="res" ' + tsarcProps.get("res_ENABLED") + '>');
	write('</td>');
	write('<td class="textlabel">' + jspResArr.get("FLT090389") + '</td>');
	write('<td class="textlabel">');
	write('<input type="text" class="textfieldfont" name="' + subGroupName + '.notifyFlag" id="notifyFlag" ' + tsarcProps.get("notifyFlag_ENABLED") + '>');
	write('</td>');
	write('<td class="textfield"> </td>');
	write('</tr>');
	write('</table>');
	write('</td>');
	write('</tr>');
	write('</table>');
	write('</td>');
	write('</tr>');
	write('</table>');
	write('</td>');
	write('</tr>');
	write('</table>');
	write('<!-- DETAILSBLOCK-END -->');
	write('</td>');
	write('</tr>');
	write('</table>');
	} //End with()
} //End function

function printFooterBlock()
{
	with (document) {
	if ((sReferralMode == 'I')||(sReferralMode == 'S')){
	write('<div align="left" class="ctable">');
	if (sReferralMode == 'S'){
	write('<input type="button" class="Button" id="Submit" value="'+jspResArr.get("FLT000193")+ '" onClick="javascript:return doRefSubmit(this);" hotKeyId="Submit" >');
	}
	writeRefFooter();
	write('<input type="button" class="Button" id="_BackRef_" value="'+jspResArr.get("FLT001721")+ '" onClick="javascript:return doSubmit(this.id);" hotKeyId="Cancel" >');
	write('</div>');
	}else{
	if(funcCode !='I'){
	write('<div class="ctable">');
	write('<input id="Submit" name="Submit" type="button" class="button"	onClick="javascript:return tsarc_det_ONCLICK1(this,this);"" value="' + jspResArr.get("FLT000193") + '" hotKeyId="Submit">');
	write('<input id="Validate" name="Validate" type="button" class="button" value="' + jspResArr.get("FLT000194") + '"	onClick="javascript:return tsarc_det_ONCLICK2(this,this);"" hotKeyId="Validate">');
	write('<input id="Cancel" name="Cancel" type="button" class="button" value="' + jspResArr.get("FLT001721") + '"	onClick="javascript:return tsarc_det_ONCLICK3(this,this.id);"" hotKeyId="Cancel">');
	}else{
	write('<div class="ctable">');
	write('<input class="button" type="button" id="Back" value="'+jspResArr.get("FLT026526")+ '" onClick="javascript:return doSubmit(this.id)" hotKeyId="Ok">');
	}
	writeFooter();
	write('</div>');
	}
	} //End with()
}//End function

function fnOnLoad()
{
	var ObjForm = document.forms[0];

	pre_ONLOAD('tsarc_det',this);

	var funcName = "this."+"locfnOnLoad";
	if(eval(funcName) != undefined){
		eval(funcName).call(this);
	}

	fnPopulateControlValues();

	if(funcCode =='V' || funcCode =='I' || funcCode =='D' || funcCode =='U' ||  funcCode =='X' || sReferralMode =='I' || sReferralMode =='S'){
		fnDisableFormDataControls('V',ObjForm,0);
	}
	fnPopUpExceptionWindow(ObjForm.actionCode);
	if((typeof(WF_IN_PROGRESS) != "undefined") && (WF_IN_PROGRESS == "PEAS")){
		checkCustErrExecNextStep(Message);
	}

	post_ONLOAD('tsarc_det',this);
}

function fnCheckMandatoryFields()
{
	var ObjForm = document.forms[0];

	return true;
}

function fnPopulateControlValues() 
{
	var ObjForm = document.forms[0];

	ObjForm.funcCode.value = funcCode;
	ObjForm.tranDate.value = tranDate;
	ObjForm.isdn.value = isdn;
	ObjForm.Amt.value = Amt;
	ObjForm.settlementref.value = settlementref;
	ObjForm.uniqueReference.value = uniqueReference;
	ObjForm.bankBranchid.value = bankBranchid;
	ObjForm.bankId.value = bankId;
	ObjForm.batchId.value = batchId;
	ObjForm.branchPhoneno.value = branchPhoneno;
	ObjForm.bvn.value = bvn;
	ObjForm.cbnAcct.value = cbnAcct;
	ObjForm.channel.value = channel;
	ObjForm.collectedAmount.value = collectedAmount;
	ObjForm.currency.value = currency;
	ObjForm.customerAccount.value = customerAccount;
	ObjForm.customerEmail.value = customerEmail;
	ObjForm.customerName.value = customerName;
	ObjForm.customerPhone.value = customerPhone;
	ObjForm.customerTin.value = customerTin;
	ObjForm.fee.value = fee;
	ObjForm.feedType.value = feedType;
	ObjForm.gifmisCode.value = gifmisCode;
	ObjForm.itemCode.value = itemCode;
	ObjForm.itemName.value = itemName;
	ObjForm.locationCode.value = locationCode;
	ObjForm.mdaCode.value = mdaCode;
	ObjForm.mdaName.value = mdaName;
	ObjForm.narrationDesc.value = narrationDesc;
	ObjForm.payColDate.value = payColDate;
	ObjForm.psspCode.value = psspCode;
	ObjForm.psspName.value = psspName;
	ObjForm.remittedAmount.value = remittedAmount;
	ObjForm.requestedAmount.value = requestedAmount;
	ObjForm.sessionId.value = sessionId;
	//ObjForm.settlementRef.value = settlementRef;
	ObjForm.tsaPcCodename.value = tsaPcCodename;
	ObjForm.tsaPcCoderef.value = tsaPcCoderef;
	ObjForm.valueDate.value = valueDate;
	ObjForm.whoPays.value = whoPays;
	ObjForm.res.value = res;
	ObjForm.notifyFlag.value = notifyFlag;
}


function tsarc_det_ONCLICK1(obj,p1)
{
	var retVal = "";
	if (preEventCall('tsarc_det',obj,'ONCLICK') == false) { 
		return false;
	}
	if ((retVal =  fnValAndSubmit(p1)) == false) {
		return false;
	}
	if (postEventCall('tsarc_det',obj,'ONCLICK') == false) { 
		return false;
	}
	return (retVal == undefined) ? true : retVal;
}

function tsarc_det_ONCLICK2(obj,p1)
{
	var retVal = "";
	if (preEventCall('tsarc_det',obj,'ONCLICK') == false) { 
		return false;
	}
	if ((retVal =  fnValAndSubmit(p1)) == false) {
		return false;
	}
	if (postEventCall('tsarc_det',obj,'ONCLICK') == false) { 
		return false;
	}
	return (retVal == undefined) ? true : retVal;
}

function tsarc_det_ONCLICK3(obj,p1)
{
	var retVal = "";
	if (preEventCall('tsarc_det',obj,'ONCLICK') == false) { 
		return false;
	}
	if ((retVal =  doSubmit(p1)) == false) {
		return false;
	}
	if (postEventCall('tsarc_det',obj,'ONCLICK') == false) { 
		return false;
	}
	return (retVal == undefined) ? true : retVal;
}
